package com.zunaidzariart.app

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

data class Sale(
    var billNo: String,
    var saleDate: String,
    var saleBy: String,
    var customerName: String,
    var mobile1: String,
    var mobile2: String,
    var size: String,
    var billAmount: String,
    var advance: String,
    var balance: String,
    var deliveryDate: String,
    var description: String,
    var status: String = "Sale"
)

class MainActivity : AppCompatActivity() {
    private val sales = mutableListOf<Sale>()
    private lateinit var content: LinearLayout
    private val burgundy = 0xFF7B1E3A.toInt()
    private val gold = 0xFFC9A227.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 24)
        }
        val bar = TextView(this).apply {
            text = title
            textSize = 24f
            setTextColor(burgundy)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 18)
        }
        root.addView(bar)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setOnClickListener { action() }
            isAllCaps = false
        }

    private fun field(hint: String): EditText =
        EditText(this).apply {
            this.hint = hint
            setPadding(12, 8, 12, 8)
        }

    private fun showHome() {
        val root = base("Zunaid Zari Art")
        val subtitle = TextView(this).apply {
            text = "Sales & Dress Status Management"
            textSize = 16f
            setTextColor(gold)
            setPadding(0, 0, 0, 18)
        }
        content.addView(subtitle)

        val search = field("Search Bill No. or Sale Date")
        content.addView(search)
        content.addView(button("🔎 Search Status") {
            val q = search.text.toString().trim()
            val matches = if (q.isEmpty()) sales else sales.filter {
                it.billNo.contains(q, true) || it.saleDate.contains(q, true)
            }
            showResults("Search Results", matches)
        })
        content.addView(button("➕ New Sale") { showSale() })
        content.addView(button("📦 Order") { showOrder() })
        content.addView(button("📦 Stock Order") { showStockOrder() })
        content.addView(button("📅 Next 30 Days Delivery") { showNext30() })
        content.addView(button("⏰ Miscellaneous Reminder") { showMisc() })
        content.addView(button("📋 All Sales / Status") { showResults("All Sales", sales) })
        setContentView(root)
    }

    private fun showSale() {
        val root = base("New Sale")
        val bill = field("Bill No. (manual shop bill book number)")
        val saleBy = field("Sale By Person Name")
        val customer = field("Customer Name")
        val mobile1 = field("Mobile Number 1")
        val mobile2 = field("Mobile Number 2")
        val size = field("Size (Normal / Large)")
        val amount = field("Bill Amount")
        val advance = field("Advance")
        val balance = field("Balance")
        val delivery = field("Delivery Date")
        val desc = field("Dress Description / Photo reference")

        listOf(bill,saleBy,customer,mobile1,mobile2,size,amount,advance,balance,delivery,desc)
            .forEach { content.addView(it) }

        content.addView(button("📷 Dress Photo Required — add from phone/WhatsApp") {
            Toast.makeText(this, "Photo selection can be connected in the next build step.", Toast.LENGTH_SHORT).show()
        })
        content.addView(button("💾 Save Sale") {
            val date = today()
            sales.add(Sale(
                bill.text.toString(), date, saleBy.text.toString(), customer.text.toString(),
                mobile1.text.toString(), mobile2.text.toString(), size.text.toString(),
                amount.text.toString(), advance.text.toString(), balance.text.toString(),
                delivery.text.toString(), desc.text.toString()
            ))
            Toast.makeText(this, "Sale saved — Bill ${bill.text}", Toast.LENGTH_SHORT).show()
            showHome()
        })
        content.addView(button("← Back") { showHome() })
        setContentView(root)
    }

    private fun showOrder() {
        val root = base("Manufacturer Order")
        val bill = field("Bill No.")
        val manufacturer = field("Manufacturer Name")
        val gone = field("Order Gone Date")
        val completion = field("Order Completion Date")
        val status = field("Status (Pending / Closed)")
        val saleBy = field("Sale By Person Name")
        listOf(bill,manufacturer,gone,completion,status,saleBy).forEach { content.addView(it) }
        content.addView(TextView(this).apply {
            text = "Automatic reminder plan: 15 days, 8 days and 3 days before completion date."
            setPadding(0, 12, 0, 12)
        })
        content.addView(button("💾 Save Order") {
            Toast.makeText(this, "Order saved. Reminder schedule recorded.", Toast.LENGTH_SHORT).show()
            showHome()
        })
        content.addView(button("← Back") { showHome() })
        setContentView(root)
    }

    private fun showStockOrder() {
        val root = base("Stock Order")
        listOf(
            field("Bill No."),
            field("Dress Description"),
            field("Manufacturer Name"),
            field("Order Gone Date"),
            field("Order Coming Date"),
            field("Sale By Person Name"),
            field("Status (Pending / Closed)")
        ).forEach { content.addView(it) }
        content.addView(TextView(this).apply {
            text = "Reminder plan: 15 days, 8 days and 3 days before the relevant date."
            setPadding(0, 12, 0, 12)
        })
        content.addView(button("💾 Save Stock Order") {
            Toast.makeText(this, "Stock order saved.", Toast.LENGTH_SHORT).show()
            showHome()
        })
        content.addView(button("← Back") { showHome() })
        setContentView(root)
    }

    private fun showNext30() {
        val root = base("Next 30 Days Delivery")
        val today = Calendar.getInstance()
        val end = today.clone() as Calendar
        end.add(Calendar.DAY_OF_YEAR, 30)
        val fmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        if (sales.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "No sales entered yet."
                textSize = 17f
            })
        } else {
            sales.sortedBy { it.deliveryDate }.forEach { s ->
                val row = TextView(this).apply {
                    text = "Bill: ${s.billNo}\nSale Date: ${s.saleDate}\nDelivery: ${s.deliveryDate}\nSale By: ${s.saleBy}\nStatus: ${s.status}\n"
                    setPadding(0, 12, 0, 12)
                }
                content.addView(row)
            }
        }
        content.addView(button("← Back") { showHome() })
        setContentView(root)
    }

    private fun showMisc() {
        val root = base("Miscellaneous Reminder")
        val work = field("Work / Reminder")
        val date = field("Date")
        val time = field("Time")
        content.addView(work); content.addView(date); content.addView(time)
        content.addView(button("Set Reminder") {
            Toast.makeText(this, "Reminder saved for ${date.text} ${time.text}", Toast.LENGTH_LONG).show()
        })
        content.addView(button("← Back") { showHome() })
        setContentView(root)
    }

    private fun showResults(title: String, list: List<Sale>) {
        val root = base(title)
        if (list.isEmpty()) {
            content.addView(TextView(this).apply { text = "No records found."; textSize = 17f })
        } else list.forEach { s ->
            content.addView(TextView(this).apply {
                text = "Bill ${s.billNo} | ${s.saleDate}\nSale By: ${s.saleBy}\nCustomer: ${s.customerName}\nDelivery: ${s.deliveryDate}\nBalance: ${s.balance}\nSTATUS: ${s.status}"
                setPadding(0, 14, 0, 14)
            })
        }
        content.addView(button("← Home") { showHome() })
        setContentView(root)
    }

    private fun today(): String =
        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
}
