# Zunaid Zari Art — Cloud Build Android Project

This is the complete project folder to upload to a Git repository for a cloud Android build.

Project root must contain:
- app/
- build.gradle
- settings.gradle
- gradle.properties
- gradle/wrapper/gradle-wrapper.properties

The app includes the agreed initial shop workflow:
- Sales-first home screen
- Manual printed bill number
- Sale by person
- Customer and two mobile numbers
- Size, bill amount, advance and balance
- Delivery date and dress description/photo placeholder
- Manufacturer Order
- Stock Order
- Next 30 Days Delivery
- Home search by bill number or sale date
- Status display
- Miscellaneous reminder

Do not upload only the app folder. Upload the entire project root.
